from multiprocessing import set_start_method
set_start_method('spawn')

